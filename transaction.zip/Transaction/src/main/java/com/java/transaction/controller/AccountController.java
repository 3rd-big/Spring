package com.java.transaction.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
public class AccountController {
    
    @RequestMapping("/")
    public String transferPage() {
        System.out.println("account");
        return "account";
    }
    
}
